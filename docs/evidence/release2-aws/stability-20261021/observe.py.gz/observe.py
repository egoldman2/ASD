"""Observe one accepted release under bounded, real public CRUD traffic."""

import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/srv/asd')
SHA = '2e7274304a4d196d45a36e295b1be0c5792310e8'
release = (ROOT / 'current').resolve()
identity = json.loads((release / 'source-metadata.json').read_text())
assert identity['source_sha'] == SHA
assert json.loads((release / 'deployment-result.json').read_text())['acceptance'] == 'passed'
sys.path.insert(0, str(release / 'cloud'))
from smoke import run, SmokeFailure

directory = ROOT / 'verification/release2-2e72743'
assert directory.is_dir()
values = dict(line.split('=', 1) for line in (release / 'cloud.env').read_text().splitlines() if line and not line.startswith('#'))
started_at = datetime.datetime.now(datetime.timezone.utc)
started = time.monotonic()
report = {'source_sha': SHA, 'release_id': identity['release_id'],
          'target_instance': identity['target_instance'], 'owner': 'Ethan Goldman',
          'command': 'SSM: existing cloud.smoke.run on public origin every 120 seconds; Docker/proc/kernel observations',
          'window_start': started_at.isoformat(), 'status': 'incomplete', 'samples': [], 'cycles': [],
          'limitations': ['One sequential synthetic demo client, not a production capacity guarantee.',
                         'Existing account DELETE deactivates disposable accounts; those rows remain.']}


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def command(*args):
    return subprocess.check_output(args, text=True, timeout=30)


def snapshot():
    assert (ROOT / 'current').resolve() == release
    ids = command('docker', 'ps', '-aq').split()
    rows = json.loads(command('docker', 'inspect', *ids))
    containers = {x['Id']: {'service': (x['Config'].get('Labels') or {}).get('com.docker.compose.service'),
                           'restarts': x['RestartCount'], 'oom_killed': x['State']['OOMKilled'],
                           'status': x['State']['Status'], 'health': x['State'].get('Health', {}).get('Status', 'healthy')} for x in rows}
    assert len(containers) == 14
    flags = {'AI_MODE_ENABLED', 'MCP_ENABLED', 'RAG_ENABLED', 'MULTI_AGENT_ENABLED'}
    observed = []
    for row in rows:
        env = dict(item.split('=', 1) for item in row['Config']['Env'] if '=' in item)
        if flags & env.keys():
            observed.append({key: env.get(key) for key in flags})
    assert len(observed) >= 4 and all(all(value == 'false' for value in item.values()) for item in observed)
    memory = {k: int(v.split()[0]) for k, v in (line.split(':', 1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines()) if k in {'MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'}}
    kernel = subprocess.run(['journalctl', '--no-pager', '-b', '_TRANSPORT=kernel', '--since', started_at.isoformat(), '--grep', 'Out of memory|oom-kill', '--output', 'cat'], capture_output=True, text=True, timeout=30)
    assert kernel.returncode in {0, 1}
    report['samples'].append({'captured_at': stamp(), 'memory_kib': memory,
                              'new_oom_events': len(kernel.stdout.splitlines()),
                              'running_healthy': all(x['status'] == 'running' and x['health'] == 'healthy' and not x['oom_killed'] for x in containers.values())})
    return containers


def save():
    report['captured_at'] = stamp()
    report['observation_seconds'] = time.monotonic() - started
    path = directory / 'stability.json'
    path.write_text(json.dumps(report, indent=2) + '\n')
    path.chmod(0o600)


try:
    report['containers_before'] = snapshot()
    deadline = started + 1800
    while time.monotonic() < deadline:
        try:
            result = run(identity['public_url'], values)
        except SmokeFailure as error:
            result = error.report
        data = (json.dumps(result, indent=2) + '\n').encode()
        path = directory / ('load-cycle-' + str(len(report['cycles']) + 1) + '.json')
        path.write_bytes(data)
        path.chmod(0o600)
        report['cycles'].append({key: result.get(key) for key in ['captured_at', 'status', 'cleanup_status', 'feature_crud']})
        report['cycles'][-1].update(check_count=len(result['checks']), all_checks_passed=all(x['passed'] for x in result['checks']), artifact_path=str(path), sha256=hashlib.sha256(data).hexdigest())
        snapshot()
        save()
        assert result['status'] == result['cleanup_status'] == 'passed'
        assert all(x['passed'] for x in result['checks'])
        time.sleep(max(0, min(120, deadline - time.monotonic())))
    report['containers_after'] = snapshot()
    report['new_oom_events'] = max(x['new_oom_events'] for x in report['samples'])
    before, after = report['containers_before'], report['containers_after']
    report['unexpected_restarts'] = sum(max(0, after[k]['restarts'] - before[k]['restarts']) for k in before.keys() & after.keys()) + len(before.keys() ^ after.keys())
    assert time.monotonic() - started >= 1800 and len(report['cycles']) >= 2
    assert not report['new_oom_events'] and not report['unexpected_restarts']
    assert all(x['running_healthy'] for x in report['samples'])
    report['status'] = 'passed'
except Exception as error:
    report['status'] = 'failed'
    report['failure_type'] = type(error).__name__
finally:
    save()
    data = json.dumps(report, separators=(',', ':'))
    assert len(data.encode()) < 23000
    print(data)
sys.exit(0 if report['status'] == 'passed' else 1)
